import DashboardLayout from "@/components/dashboard-layout"
import MetricCard from "@/components/metric-card"
import ChartCard from "@/components/chart-card"
import { DollarSign, TrendingUp, Users, UserPlus, Filter } from "lucide-react"

export default function Dashboard() {
  return (
    <DashboardLayout>
      <div className="flex items-center justify-between p-4 border-b">
        <div className="flex items-center gap-2">
          <span className="font-medium">Select period:</span>
          <div className="flex items-center border rounded-md px-3 py-1.5">
            <span>2025 - YTD</span>
            <Filter className="ml-2 h-4 w-4 text-gray-500" />
          </div>
        </div>
        <div className="flex items-center gap-4">
          <div className="relative">
            <input type="text" placeholder="Search Household..." className="pl-8 pr-4 py-1.5 border rounded-md w-64" />
            <svg
              className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
              />
            </svg>
          </div>
          <button className="flex items-center gap-1 border rounded-md px-3 py-1.5">
            <Filter className="h-4 w-4" />
            <span>Filter Data</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 p-4">
        <MetricCard
          title="Total Assets Under Management"
          value="$250,000,000"
          icon={<DollarSign className="h-6 w-6" />}
        />
        <MetricCard title="YTD Book Growth Rate" value="36.2%" icon={<TrendingUp className="h-6 w-6" />} />
        <MetricCard title="YTD New Clients" value="36" icon={<Users className="h-6 w-6" />} />
        <MetricCard title="YTD New Prospects" value="29" icon={<UserPlus className="h-6 w-6" />} />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 p-4">
        <ChartCard title="Client Segmentation" type="pie" />
        <ChartCard title="Client Meetings by Month" type="bar" />
        <ChartCard title="Client Segmentation" type="bar" />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 p-4">
        <ChartCard title="New Contacts" type="pie" />
        <ChartCard title="Total Client Activities by Month" type="bar" />
        <ChartCard title="Income Source per Month" type="stacked-bar" />
      </div>
    </DashboardLayout>
  )
}

