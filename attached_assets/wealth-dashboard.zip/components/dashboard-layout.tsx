"use client"

import type React from "react"

import { useState } from "react"
import { Home, Flag, PieChart, Award, Bell, Settings, Menu, X } from "lucide-react"
import Image from "next/image"

export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode
}) {
  const [sidebarOpen, setSidebarOpen] = useState(false)

  return (
    <div className="flex h-screen bg-gray-100">
      {/* Mobile sidebar toggle */}
      <div className="lg:hidden fixed top-4 left-4 z-50">
        <button onClick={() => setSidebarOpen(!sidebarOpen)} className="p-2 rounded-md bg-white shadow-md">
          {sidebarOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </button>
      </div>

      {/* Sidebar */}
      <div
        className={`fixed inset-y-0 left-0 transform ${
          sidebarOpen ? "translate-x-0" : "-translate-x-full"
        } lg:translate-x-0 transition duration-200 ease-in-out lg:relative lg:flex flex-col w-16 bg-blue-600 text-white z-40`}
      >
        <div className="p-4 flex justify-center">
          <div className="h-8 w-8 bg-white rounded-full flex items-center justify-center">
            <PieChart className="h-5 w-5 text-blue-600" />
          </div>
        </div>
        <nav className="flex-1 flex flex-col items-center gap-8 py-8">
          <a href="#" className="p-2 rounded-full bg-blue-700">
            <Home className="h-6 w-6" />
          </a>
          <a href="#" className="p-2 hover:bg-blue-700 rounded-full">
            <Flag className="h-6 w-6" />
          </a>
          <a href="#" className="p-2 hover:bg-blue-700 rounded-full">
            <PieChart className="h-6 w-6" />
          </a>
          <a href="#" className="p-2 hover:bg-blue-700 rounded-full">
            <Award className="h-6 w-6" />
          </a>
          <a href="#" className="p-2 hover:bg-blue-700 rounded-full">
            <Bell className="h-6 w-6" />
          </a>
        </nav>
        <div className="p-4 flex justify-center">
          <a href="#" className="p-2 hover:bg-blue-700 rounded-full">
            <Settings className="h-6 w-6" />
          </a>
        </div>
      </div>

      {/* Main content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <header className="bg-white shadow-sm z-10">
          <div className="flex items-center justify-between p-4">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-full overflow-hidden">
                <Image
                  src="/placeholder.svg?height=40&width=40"
                  alt="Profile"
                  width={40}
                  height={40}
                  className="object-cover"
                />
              </div>
              <h1 className="text-xl font-bold">Radar Capital Management</h1>
            </div>
            <div className="flex gap-2">
              <button className="flex items-center gap-2 px-4 py-2 border rounded-md">
                <svg
                  className="h-5 w-5"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z"
                  />
                </svg>
                Ask AI...
              </button>
              <button className="flex items-center gap-2 px-4 py-2 border rounded-md">
                <svg
                  className="h-5 w-5"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M18.364 5.636l-3.536 3.536m0 5.656l3.536 3.536M9.172 9.172L5.636 5.636m3.536 9.192l-3.536 3.536M21 12a9 9 0 11-18 0 9 9 0 0118 0zm-5 0a4 4 0 11-8 0 4 4 0 018 0z"
                  />
                </svg>
                Support
              </button>
            </div>
          </div>
        </header>

        {/* Content */}
        <main className="flex-1 overflow-y-auto bg-gray-100">{children}</main>
      </div>
    </div>
  )
}

