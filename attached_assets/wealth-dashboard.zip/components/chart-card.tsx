"use client"

import { useEffect, useRef } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Filter } from "lucide-react"
import { Chart, registerables } from "chart.js"

Chart.register(...registerables)

interface ChartCardProps {
  title: string
  type: "pie" | "bar" | "stacked-bar"
}

export default function ChartCard({ title, type }: ChartCardProps) {
  const chartRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    if (!chartRef.current) return

    const ctx = chartRef.current.getContext("2d")
    if (!ctx) return

    // Destroy previous chart instance if it exists
    const chartInstance = Chart.getChart(chartRef.current)
    if (chartInstance) {
      chartInstance.destroy()
    }

    // Create chart based on type
    if (type === "pie") {
      new Chart(ctx, {
        type: "doughnut",
        data: {
          labels:
            type === "pie" && title === "New Contacts" ? ["Q1", "Q2", "Q3", "Q4"] : ["Gold", "Diamond", "Platinum"],
          datasets: [
            {
              data: type === "pie" && title === "New Contacts" ? [5, 13, 6, 21] : [29.4, 41.2, 29.4],
              backgroundColor: ["#1e40af", "#3b82f6", "#38bdf8", "#0f172a"],
              borderWidth: 0,
            },
          ],
        },
        options: {
          responsive: true,
          cutout: "60%",
          plugins: {
            legend: {
              position: "right",
              labels: {
                boxWidth: 12,
                padding: 15,
              },
            },
          },
        },
      })
    } else if (type === "bar") {
      const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]

      let data
      if (title === "Client Meetings by Month") {
        data = [5, 12, 3, 7, 10, 11, 8, 5, 12, 18, 25, 8]
      } else if (title === "Total Client Activities by Month") {
        data = [9000, 22000, 12000, 27000, 38000, 34000, 29000, 28000, 39000, 37000, 34000, 32000]
      } else if (title === "Client Segmentation") {
        return new Chart(ctx, {
          type: "bar",
          data: {
            labels: ["Segment 1", "Segment 2", "Segment 3", "Segment 4", "Segment 5"],
            datasets: [
              {
                data: [65, 30, 20, 10, 15],
                backgroundColor: "#3b82f6",
                borderWidth: 0,
                borderRadius: 4,
              },
            ],
          },
          options: {
            responsive: true,
            scales: {
              y: {
                beginAtZero: true,
                grid: {
                  display: true,
                  drawBorder: false,
                },
              },
              x: {
                grid: {
                  display: false,
                  drawBorder: false,
                },
              },
            },
            plugins: {
              legend: {
                display: false,
              },
            },
          },
        })
      }

      new Chart(ctx, {
        type: "bar",
        data: {
          labels: months,
          datasets: [
            {
              data: data,
              backgroundColor: "#3b82f6",
              borderWidth: 0,
              borderRadius: 4,
            },
          ],
        },
        options: {
          responsive: true,
          scales: {
            y: {
              beginAtZero: true,
              grid: {
                display: true,
                drawBorder: false,
              },
            },
            x: {
              grid: {
                display: false,
                drawBorder: false,
              },
            },
          },
          plugins: {
            legend: {
              display: false,
            },
          },
        },
      })
    } else if (type === "stacked-bar") {
      const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]

      new Chart(ctx, {
        type: "bar",
        data: {
          labels: months,
          datasets: [
            {
              label: "Type A",
              data: [5000, 12000, 8000, 15000, 18000, 12000, 8000, 15000, 18000, 22000, 18000, 15000],
              backgroundColor: "#3b82f6",
              borderWidth: 0,
            },
            {
              label: "Type B",
              data: [3000, 5000, 10000, 8000, 12000, 10000, 5000, 8000, 12000, 10000, 8000, 10000],
              backgroundColor: "#38bdf8",
              borderWidth: 0,
            },
            {
              label: "Type C",
              data: [2000, 3000, 5000, 7000, 8000, 10000, 7000, 5000, 10000, 8000, 7000, 6000],
              backgroundColor: "#0f172a",
              borderWidth: 0,
            },
          ],
        },
        options: {
          responsive: true,
          scales: {
            y: {
              stacked: true,
              beginAtZero: true,
              grid: {
                display: true,
                drawBorder: false,
              },
            },
            x: {
              stacked: true,
              grid: {
                display: false,
                drawBorder: false,
              },
            },
          },
          plugins: {
            legend: {
              display: false,
            },
          },
        },
      })
    }
  }, [title, type])

  return (
    <Card className="overflow-hidden">
      <CardHeader className="flex flex-row items-center justify-between p-4 pb-2">
        <CardTitle className="text-md font-medium">{title}</CardTitle>
        <button className="text-gray-400 hover:text-gray-500">
          <Filter className="h-4 w-4" />
        </button>
      </CardHeader>
      <CardContent className="p-4">
        <div className="h-64">
          <canvas ref={chartRef} />
        </div>
      </CardContent>
    </Card>
  )
}

