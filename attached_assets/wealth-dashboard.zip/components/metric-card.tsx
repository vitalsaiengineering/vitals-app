import type React from "react"
import { Filter } from "lucide-react"
import { Card, CardContent, CardHeader } from "@/components/ui/card"

interface MetricCardProps {
  title: string
  value: string
  icon: React.ReactNode
}

export default function MetricCard({ title, value, icon }: MetricCardProps) {
  return (
    <Card className="overflow-hidden">
      <CardHeader className="flex flex-row items-center justify-between p-4 pb-2">
        <div className="rounded-full bg-gray-100 p-2">{icon}</div>
        <button className="text-gray-400 hover:text-gray-500">
          <Filter className="h-4 w-4" />
        </button>
      </CardHeader>
      <CardContent className="p-4 pt-2">
        <h3 className="text-sm font-medium text-gray-500">{title}</h3>
        <p className="text-2xl font-bold">{value}</p>
      </CardContent>
    </Card>
  )
}

